/******************************************************************
** 
** CS-305 Project 2
** ServerEndpoints.java
** 
** Dante Trisciuzzi
** Southern New Hampshire University
** CS-305-T3311 Software Security
** Dr. Vivian Lyon
** February 15, 2023
**
******************************************************************/

package com.snhu.sslserver;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
class ServerEndpoints {
	
	/**
	 * The function for the '/hash' API end point
	 *
	 * @return a demo output for the hashing algorithm
	 */
	@RequestMapping("/hash")
	public String demonstrateHash() {
		
		// Create a string builder for the return value
		StringBuilder sb = new StringBuilder();
		
		// Create (constant) data and append formatting to the output builder
	    final String data = "Dante Trisciuzzi";
	    sb.append("<p>Original Data: ").append(data);
	    
	    // Generate hash and append to output builder
	    final String hash = CipherProvider.getSha256HashString(data);
	    sb.append("</p><p>Cipher Used: SHA-256 | Hashed Data: ").append(hash).append("</p>");
	    
	    // Return formatted output
	    return sb.toString();
	}
}