/******************************************************************
** 
** CS-305 Project 2
** CipherProvider.java
** 
** Dante Trisciuzzi
** Southern New Hampshire University
** CS-305-T3311 Software Security
** Dr. Vivian Lyon
** February 15, 2023
**
******************************************************************/

package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class CipherProvider {
	
	/**
	 * Converts a byte array to a hexadecimal string.
	 *
	 * @param bytes the byte array to convert
	 * @return a hexadecimal string representing the input bytes
	 */
	final private static String bytesToHexString(byte[] bytes) {
		
		// Declare (constant) hex mask
	    final int MASK = 0xff;
	    
	    // Create our output string builder
	    StringBuilder hexStringBuffer = new StringBuilder();
	    
	    // ForEach loop to mash each byte
	    for (byte hashByte : bytes) {
	        int intVal = MASK & hashByte;
	        hexStringBuffer.append(String.format("%02x", intVal));
	    }
	    
	    // Return output as a string
	    return hexStringBuffer.toString();
	}
	

	/**
	 * Returns a SHA-256 Hash for the given string
	 *
	 * @param input The input string
	 * @return The hexadecimal string for the SHA-256 checksum
	 */
	final static String getSha256HashString(String input) {
		
		// Use try/catch here in case our algorithm is missing from the digest
	    try {
	    	
	    	//Setup algorithm cipher requirements
	        MessageDigest md = MessageDigest.getInstance("SHA-256");
	        byte[] inputBytes = input.getBytes(StandardCharsets.UTF_8);
	        
	        // Create hash
	        byte[] hashBytes = md.digest(inputBytes);
	        
	        //return hash as a string
	        return bytesToHexString(hashBytes);
	    
	    // On missing algorithm
	    } catch (NoSuchAlgorithmException e) {
	    	
	    	// Use a runtime exception to avoid declaring the checked exception
	        throw new RuntimeException("SHA-256 algorithm not found", e);
	    }
	}
}
